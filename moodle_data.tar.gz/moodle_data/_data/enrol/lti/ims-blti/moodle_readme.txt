This library was originally published by the IMS at https://code.google.com/p/ims-dev/ which no longer exists. The
current code was taken from https://github.com/jfederico/ims-dev/tree/master/basiclti/php-simple/ims-blti - with
several changes to the code (including bug fixes). As the library is no longer supported upgrades are not possible.
In future releases we should look into using a supported library.
